package adt.bt.symetric;

import adt.bt.BTNode;

public class SymetricBTImpl<T> implements SymetricBT<T>{

	protected BTNode<T> root;

	
	public SymetricBTImpl() {
		root = new BTNode<T>();
	}

	@Override
	public boolean isSymetric() {
		// TODO Implement yout code here
		throw new UnsupportedOperationException("Not implemented yet!");
	}

	@Override
	public BTNode<T> getRoot() {
		return root;
	}

}
