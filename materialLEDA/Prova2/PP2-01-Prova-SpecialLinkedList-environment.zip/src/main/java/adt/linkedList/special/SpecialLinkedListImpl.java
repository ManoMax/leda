package adt.linkedList.special;

import adt.linkedList.SingleLinkedListImpl;

public class SpecialLinkedListImpl<T> extends SingleLinkedListImpl<T> implements SpecialLinkedList<T> {

	@Override
	public void swap(T elem1, T elem2) {
		// TODO Implement your code here
		throw new UnsupportedOperationException("Not implemented yet!");
	}

	@Override
	public T elementFromTheEnd(int k) {
		// TODO Implement your code here
		throw new UnsupportedOperationException("Not implemented yet!");

	}

}
